
==============================================================================
REQUISITION IMPORT FAILS WITH MULTI_DISTRIBUTION ERROR OR INVALID ACCOUNTS
==============================================================================

Update   - 12790516
Product  - Purchasing
Release  - R12
Platform - Linux x86
Built    - JUL-27-2011 23:37:18

Instructions For Applying This Patch
==============================================================================


Preparation Tasks
==============================================================================
The tasks in this section can be completed without taking any Applications
services or users offline.


There are no tasks to be performed in this section.


Pre-install Tasks
==============================================================================
You must shut down all Application tier services before performing the
tasks in this section.


There are no tasks to be performed in this section.


Apply The Patch
==============================================================================



There are no tasks to be performed in this section.


Post-install Tasks
==============================================================================
You must complete the tasks in this section before starting up Application
tier services.


There are no tasks to be performed in this section.


Finishing Tasks
==============================================================================
You may complete the tasks in this section at any time after the update,
without taking any services or users offline.


There are no tasks to be performed in this section.


Additional Information
==============================================================================



There are no tasks to be performed in this section.
==============================================================================
Description
==============================================================================

***************************************************************
        Patch applicable only for Release R12
***************************************************************


1. Problem Description:
    REQUISITION IMPORT FAILS WITH MULTI_DISTRIBUTION ERROR OR INVALID ACCOUNTS


2. Resolution:
    Requisition Import Successfully loads the multiple distributions

3. Patch Applicable for versions:
     R12 Purchasing.

4. Dependant Applications:
     None.

5. Patch to be applied:
     Server.

6. Patch applicable only when a particular application installed:
     Oracle Purchasing.

7. Pre-patch application steps
 None

8. Post patch application steps
      Bounce the Apache after patch has been applied

9. Successful patch installation checks:
      Check the version of following files
      src/reqimp/pocir.opc -- 120.11.12010000.3

==============================================================================
Bugs Fixed
==============================================================================
The following bugs are fixed by this patch:

12790516 - REQUISITION IMPORT FAILS WITH MULTI_DISTRIBUTION ERROR OR INVALID ACCOUNTS


